﻿namespace DefaultNamespace
{
    public class Gameplay
    {
        
    }
}