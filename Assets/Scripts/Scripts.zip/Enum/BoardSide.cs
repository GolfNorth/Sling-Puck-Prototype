﻿namespace SlingPuck.Enum
{
    public enum BoardSide
    {
        Upper,
        Lower,
        Right,
        Left
    }
}