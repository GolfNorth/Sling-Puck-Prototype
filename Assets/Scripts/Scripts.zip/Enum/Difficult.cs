﻿namespace SlingPuck.Enum
{
    public enum Difficult
    {
        Easy,
        Middle,
        Hard
    }
}