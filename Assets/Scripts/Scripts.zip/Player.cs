﻿using UnityEngine;
using UnityEngine.InputSystem;

public class Player : MonoBehaviour
{
    public BoardSide side;
    public new Camera camera;
    public bool lockY;

    public InputAction grabAction;
    public InputAction moveAction;

    private Puck _puck = null;
    private float _lastPositionY = 0;

    private void Start()
    { 
        grabAction.started += GrabActionOnstarted;
        grabAction.canceled += GrabActionOncanceled;
        
        moveAction.performed += MoveActionOnperformed;
    }

    private void OnEnable()
    {
        grabAction.Enable();
        moveAction.Enable();
    }

    private void OnDisable()
    {
        grabAction.Disable();
        moveAction.Disable();
    }

    private void MoveActionOnperformed(InputAction.CallbackContext obj)
    {
        var test = camera.ScreenPointToRay(Mouse.current.position.ReadValue());
        
        if (Physics.Raycast(camera.ScreenPointToRay(Mouse.current.position.ReadValue()), out var hit, Mathf.Infinity, LayerMask.GetMask("Field")))
        {
            var newPosition = new Vector3(hit.point.x, hit.point.y, 0);
            
            GameBoard.MoveToField(side, ref newPosition);

            if (_puck != null && lockY) GameBoard.LockY(side, ref newPosition, ref _lastPositionY);

            transform.position = newPosition;
        }
    }

    private void GrabActionOncanceled(InputAction.CallbackContext obj)
    {
        if (_puck == null) return;
        
        _puck.Release();
        _puck = null;
    }

    private void GrabActionOnstarted(InputAction.CallbackContext obj)
    {
        if (_puck != null) return;

        if (Physics.Raycast(camera.ScreenPointToRay(Mouse.current.position.ReadValue()), out var hit, Mathf.Infinity, LayerMask.GetMask("Puck")))
        {
            var puckGameObject = hit.collider.transform.parent.gameObject;
            _puck = puckGameObject.GetComponent<Puck>();

            if (_puck.Side != side) return;
            
            _puck.Grab(transform);

            _lastPositionY = puckGameObject.transform.position.y;
        }
    }
}
