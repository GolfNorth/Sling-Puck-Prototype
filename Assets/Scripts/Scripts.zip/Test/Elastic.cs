﻿using UnityEngine;

public class Elastic : MonoBehaviour
{
    public GameObject beginElastic;
    
    public GameObject endElastic;

    public GameObject linkPrefab;
    
    public int links = 60;

    private void Start ()
    {
        GenerateRope();
    }

    private void GenerateRope ()
    {
        var beginPosition = beginElastic.GetComponent<Transform>().position;
        var endPosition = endElastic.GetComponent<Transform>().position;
        var positionStep = new Vector3((endPosition.x - beginPosition.x) / (links + 1), 0, 0);
        
        var lastRigidbody = beginElastic.GetComponent<Rigidbody>();
        var lastPosition = beginPosition;
        
        for (var i = 0; i < links; i++)
        {
            lastPosition += positionStep;
            
            var link = Instantiate(linkPrefab, new Vector3(lastPosition.x, lastPosition.y, lastPosition.z), Quaternion.identity, transform);
            var joint = link.GetComponent<HingeJoint>();
            
            joint.connectedBody = lastRigidbody;

            if (i < links - 1)
            {
                lastRigidbody = link.GetComponent<Rigidbody>();
            }
            else
            {
                joint = endElastic.GetComponent<HingeJoint>();
                joint.connectedBody = link.GetComponent<Rigidbody>();
            }

			
        }
    }
}