﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ElasticEnd : MonoBehaviour
{
    public void ConnectRopeEnd (Rigidbody2D endRB)
    {
        var joint = gameObject.AddComponent<HingeJoint2D>();
        joint.autoConfigureConnectedAnchor = true;
        joint.connectedBody = endRB;
    }
}
