﻿using UnityEngine;
using Random = UnityEngine.Random;

public class PuckTest : MonoBehaviour
{
    private Rigidbody2D _rb2D;
    public float thrust = 40.0f;

    private void Start()
    {
        _rb2D = gameObject.GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            //transform.position = new Vector3(0.0f, -7.5f, 0.0f);
            var direction = new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f), 0);
            _rb2D.AddForce(direction.normalized * thrust, ForceMode2D.Impulse);
            Debug.Log(transform.up);
            Debug.Log(direction.normalized);
            //_rb2D.AddForce(transform.up * _thrust, ForceMode2D.Impulse);
        }
    }
}
