﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.Mathematics;
using UnityEngine;

public class TestRubber : MonoBehaviour
{
    public BoardSide boardSide;
    public Transform startPoint;
    public Transform endPoint;
    public float puckRadius;
    public float MaxSug;

    private List<GameObject> _innerPucks;
    private List<Vector3> _wayPoints;
    private Vector3 _startPointPosition;
    private Vector3 _endPointPosition;
    private Vector3 _puckRadius;

    // Start is called before the first frame update
    private void Start()
    {
        _startPointPosition = startPoint.position;
        _endPointPosition = endPoint.position;
        _innerPucks = new List<GameObject>();
        _wayPoints = new List<Vector3>();
        _puckRadius = new Vector3(0, boardSide == BoardSide.Upper ? puckRadius : -puckRadius, 0);
    }

    // Update is called once per frame
    private void Update()
    {
        SortPucks();
        DrawRubberRope();
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        _innerPucks.Add(col.gameObject);
        Debug.Log(col.gameObject.name + " added");
        SortPucks();
    }
    
    private void OnTriggerExit2D(Collider2D col)
    {
        _innerPucks.Remove(col.gameObject);
        Debug.Log(col.gameObject.name + " removed");
        SortPucks();
    }

    private void SortPucks()
    {
        _innerPucks.Sort((p1, p2) => p1.transform.position.x >= p2.transform.position.x ? 1 : -1);
    }

    private Vector3 GetTangentPosition(Vector3 puckPosition, Vector3 outsidePointPosition)
    {
        return (puckPosition + outsidePointPosition).normalized * puckRadius + puckPosition;
    }
    
    private void DrawRubberRope()
    {
        _wayPoints.Clear();
        
        _wayPoints.Add(_startPointPosition);
        
        if (_innerPucks.Count > 1)
        {
            CreateWayPoints(_startPointPosition);
            CreateWayPoints(_endPointPosition);
        }
        else if (_innerPucks.Count == 1)
        {
            _wayPoints.Add(GetTangentPosition(_innerPucks[0].transform.position, _startPointPosition));
            _wayPoints.Add(_innerPucks[0].transform.position + _puckRadius);
            _wayPoints.Add(GetTangentPosition(_innerPucks[0].transform.position, _endPointPosition));
        }
        
        _wayPoints.Add(_endPointPosition);
        
        _wayPoints.Sort((p1, p2) => p1.x >= p2.x ? 1 : -1);

        for (var i = 1; i < _wayPoints.Count; i++)
            Debug.DrawLine(_wayPoints[i - 1], _wayPoints[i], Color.green);
    }

    private void CreateWayPoints(Vector3 beginning)
    {
        var lowerPuck = _innerPucks.Aggregate((p1, p2) =>
            math.abs(p1.transform.position.y) >= math.abs(p2.transform.position.y) ? p1 : p2);
        
        var lowerPuckPosition = lowerPuck.transform.position;
        
        var raycastHits = new List<RaycastHit2D>();
        var contactFilter = new ContactFilter2D()
        {
            layerMask = LayerMask.GetMask("PuckLayer"),
            useLayerMask = true
        };
        
        var direction = GetTangentPosition(lowerPuckPosition, beginning) - beginning;

        while (Physics2D.Raycast(beginning, direction.normalized, contactFilter, raycastHits, direction.magnitude) > 0)
        {
            var lastNormal = direction.normalized;
            var nextWayPointPuck = raycastHits.First().collider.gameObject;
            
            foreach (var hit in raycastHits)
            {
                var newNormal = (GetTangentPosition(hit.collider.gameObject.transform.position, beginning) - beginning).normalized;

                if (!(math.abs(lastNormal.y) < math.abs(newNormal.y))) continue;
                
                lastNormal = newNormal;
                nextWayPointPuck = hit.collider.gameObject;
            }
            
            _wayPoints.Add(GetTangentPosition(nextWayPointPuck.transform.position, beginning));

            beginning = nextWayPointPuck.transform.position + _puckRadius;
        }
    }
}
