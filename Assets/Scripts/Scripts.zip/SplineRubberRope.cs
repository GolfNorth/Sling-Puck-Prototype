﻿using SplineMesh;
using UnityEngine;

public class SplineRubberRope : MonoBehaviour
{
    private Spline _spline;
    
    public RubberRope rubberRope;

    private void Start()
    {
        _spline = GetComponent<Spline>();
    }

    private void Update()
    {
        //if (!rubberRope.IsPuckInside) return;

        _spline.nodes[2].Position = rubberRope.TangentA;
        _spline.nodes[3].Position = rubberRope.LaunchPosition;
        _spline.nodes[4].Position = rubberRope.TangentB;
    }
}
