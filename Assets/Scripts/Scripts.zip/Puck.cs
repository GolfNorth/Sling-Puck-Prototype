﻿using System;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.InputSystem;

public class Puck : MonoBehaviour
{
    public bool InHand { get; private set; }
    public Transform Transform => transform;
    public GameObject GameObject => gameObject;

    public Rigidbody2D Rigidbody2D => _rigidbody;

    public event EventHandler Releasing;
    public event EventHandler Released;
    
    public BoardSide Side => transform.position.y >= 0 ? BoardSide.Upper : BoardSide.Lower;
    
    private Rigidbody2D _rigidbody;
    private TargetJoint2D _targetJoint;
    private Transform _playerTransform;

    private void Start()
    {
        InHand = false;

        _targetJoint = GetComponent<TargetJoint2D>();
        _rigidbody = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        if (InHand)
        {
            var playerPosition = _playerTransform.position;

            _targetJoint.target = new Vector2(playerPosition.x, playerPosition.y);
        }
        
    }

    /// <summary>
    ///     Схватить шайбу
    /// </summary>
    /// <param name="playerTransform">Трансформ игрока схватившего шайбу</param>
    public void Grab(Transform playerTransform)
    {
        Debug.Log($"{gameObject.name} grabbed");
        
        InHand = true;
        
        gameObject.layer = LayerMask.NameToLayer("Puck Ignore");

        _playerTransform = playerTransform;
        _targetJoint.enabled = true;
        _rigidbody.constraints = RigidbodyConstraints2D.FreezeRotation;
    }

    /// <summary>
    ///     Отпустить шайбу
    /// </summary>
    public void Release()
    {
        Debug.Log($"{gameObject.name} released");
        
        Releasing?.Invoke(null, null);
        
        InHand = false;
        
        gameObject.layer = LayerMask.NameToLayer("Puck");

        _playerTransform = null;
        _targetJoint.enabled = false;
        _rigidbody.constraints = RigidbodyConstraints2D.None;
        
        Released?.Invoke(null, null);
    }
}