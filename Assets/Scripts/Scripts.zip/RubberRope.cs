﻿using System;
using UnityEngine;

public class RubberRope : MonoBehaviour
{
    public BoardSide side;
    public Transform startPoint;
    public Transform endPoint;
    public PolygonCollider2D polygonCollider;
    public float maxForce = 600f;
    
    public Vector2 TangentA => _tangentA;
    public Vector2 TangentB => _tangentB;
    public Vector3 LaunchPosition => _launchPosition;

    private Puck _puck;
    private Vector2 _tangentA;
    private Vector2 _tangentB;
    private Vector3 _launchPosition;
    private Vector3 _startPosition;
    private Vector3 _endPosition;
    private Vector2 _originalPolygonPoint;
    private float _tensionForMaxForce;

    private void Start()
    {
        _startPosition = startPoint.position;
        _endPosition = endPoint.position;

        var maxTensionPosition = side == BoardSide.Upper
            ? _startPosition + new Vector3(0, GameBoard.RubberRopeHeight, 0)
            : _startPosition - new Vector3(0, GameBoard.RubberRopeHeight, 0);

        _tensionForMaxForce = Vector3.Distance(_startPosition, maxTensionPosition)
                              + Vector3.Distance(_endPosition, maxTensionPosition) 
                              - Vector3.Distance(_startPosition, _endPosition);
        
        _originalPolygonPoint = new Vector2(
            0,
            side == BoardSide.Upper 
                ? GameBoard.RubberRopePositionY
                : -GameBoard.RubberRopePositionY);
        
        _launchPosition = _tangentA = _tangentB = _originalPolygonPoint;
    }

    private void Update()
    {
        if (_puck == null) return;

        var points = polygonCollider.points;
        var packPosition = _puck.Transform.position;
        
        _tangentA = points[0] = GetTangent(packPosition, GameBoard.PuckRadius, _startPosition);
        _tangentB = points[1] = GetTangent(packPosition, GameBoard.PuckRadius, _endPosition);

        polygonCollider.SetPath(0, points);
        
        _launchPosition = GetLaunchPosition(packPosition, _tangentA, _tangentB);
    }

    private void OnTriggerEnter2D(Collider2D puckCollider)
    {
        if (_puck != null) return;
        if (puckCollider.gameObject.layer != LayerMask.NameToLayer("Puck Ignore")) return;
        
        _puck = puckCollider.gameObject.GetComponent<Puck>();
        _puck.Releasing += PuckOnReleasing;
    }

    private void PuckOnReleasing(object sender, EventArgs e)
    {
        var force = GetForce();
        var direction = GetDirection(_puck.Transform.position, _launchPosition, force);

        _puck.Rigidbody2D.AddForce(direction, ForceMode2D.Impulse);
    }

    private void OnTriggerExit2D(Collider2D puckCollider)
    {
        if (_puck.GameObject != puckCollider.gameObject) return;
        
        _puck.Releasing -= PuckOnReleasing;
        _puck = null;
        
        var points = polygonCollider.points;
        
        _launchPosition = _tangentA = _tangentB = points[0] = points[1] = _originalPolygonPoint;

        polygonCollider.SetPath(0, points);
    }
    
    private Vector2 GetTangent(Vector2 center, float radius, Vector2 point)
    {
        point -= center;
        
        var p = point.magnitude;

        var a = radius * radius / p;    
        var q = radius * Mathf.Sqrt((p * p) - (radius * radius)) / p;
     
        var pN  = point / p;
        var pNp = new Vector2(-pN.y, pN.x);
        var va  = pN * a;

        var tangentA = va + pNp * q;
        var tangentB = va - pNp * q;
        
        var tangent = side == BoardSide.Upper
            ? tangentA.y > tangentB.y ? tangentA : tangentB
            : tangentA.y < tangentB.y ? tangentA : tangentB;
        
        tangent += center;
     
        return tangent;
    }
    
    private Vector3 GetDirection(Vector3 center, Vector3 launchPosition, float force)
    {
        return (center - launchPosition).normalized * force + launchPosition;
    }

    private Vector3 GetLaunchPosition(Vector3 center, Vector3 tangentA, Vector3 tangentB)
    {
        tangentA -= center;
        tangentB -= center;

        return Vector3.Slerp(tangentA, tangentB, 0.5f) + center;
    }

    private float GetForce()
    {
        var tension = Vector3.Distance(_startPosition, _tangentA)
                      + Vector3.Distance(_tangentA, _launchPosition)
                      + Vector3.Distance(_launchPosition, _tangentB)
                      + Vector3.Distance(_tangentB, _endPosition)
                      - Vector3.Distance(_startPosition, _endPosition);

        var force = tension > 0 ? maxForce * Mathf.Sqrt(tension / _tensionForMaxForce) : 0;
        
        return force;
    }
}
