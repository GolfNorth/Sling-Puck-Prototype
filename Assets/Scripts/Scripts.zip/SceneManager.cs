﻿using UnityEngine;
using SlingPuck.Enum;

public class SceneManager : MonoBehaviour
{
    public Difficult difficult;
    
    public GameObject rubberRopes;
    public GameObject lowerRubberRope;
    public GameObject upperRubberRope;

    public GameBoard GameBoard
    {
        get => _gameBoard;
        private set => _gameBoard = value;
    }

    private GameBoard _gameBoard;
    
    

    private void Awake()
    {
        difficult = Difficult.Hard;
    
        Instantiate(upperRubberRope, rubberRopes.transform);
        Instantiate(lowerRubberRope, rubberRopes.transform);
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
