﻿using UnityEngine;
using SlingPuck.Enum;

namespace SlingPuck
{
    public class Crossbar
    {
        private float _width;
        private float _height;
        private float _widthEasy;
        private float _widthMiddle;
        private float _widthHard;
        private GameObject _colliderEasy;
        private GameObject _colliderMiddle;
        private GameObject _colliderHard;
        private GameObject _meshEasy;
        private GameObject _meshMiddle;
        private GameObject _meshHard;

        public Crossbar(Difficult difficult, GameObject colliderEasy, GameObject colliderMiddle, GameObject colliderHard, GameObject meshEasy, GameObject meshMiddle, GameObject meshHard)
        {
            _height = 1f;
            _widthEasy = 5.6f;
            _widthMiddle = 5.0f;
            _widthHard = 4.4f;

            _colliderEasy = colliderEasy;
            _colliderMiddle = colliderMiddle;
            _colliderHard = colliderHard;

            _meshEasy = meshEasy;
            _meshMiddle = meshMiddle;
            _meshHard = meshHard;
            
            SwitchDifficult(difficult);
        }

        public void SwitchDifficult(Difficult difficult)
        {
            switch (difficult)
            {
                case Difficult.Middle:
                    _width = _widthMiddle;
                    
                    _colliderEasy.SetActive(false);
                    _colliderMiddle.SetActive(true);
                    _colliderHard.SetActive(false);

                    _meshEasy.SetActive(false);
                    _meshMiddle.SetActive(true);
                    _meshHard.SetActive(false);
                    
                    break;
                case Difficult.Hard:
                    _width = _widthHard;
                    
                    _colliderEasy.SetActive(false);
                    _colliderMiddle.SetActive(false);
                    _colliderHard.SetActive(true);

                    _meshEasy.SetActive(false);
                    _meshMiddle.SetActive(false);
                    _meshHard.SetActive(true);
                    
                    break;
                case Difficult.Easy:
                default:
                    _width = _widthEasy;
                    
                    _colliderEasy.SetActive(true);
                    _colliderMiddle.SetActive(false);
                    _colliderHard.SetActive(false);

                    _meshEasy.SetActive(true);
                    _meshMiddle.SetActive(false);
                    _meshHard.SetActive(false);
                    
                    break;
            }
            
            
        }

        public float Width => _width;

        public float Height => _height;
    }
}