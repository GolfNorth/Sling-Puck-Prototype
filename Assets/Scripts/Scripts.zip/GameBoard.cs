﻿using Enum;
using UnityEngine;

public class GameBoard : MonoBehaviour
{
    [Header("Rubber Rope Settings")]
    [SerializeField]
    private Transform rubberRopesTransform;
    [SerializeField]
    private GameObject lowerRubberRopePrefab;
    [SerializeField]
    private GameObject upperRubberRopePrefab;
    [SerializeField]
    private static float RubberRopeThickness => .3f;
    [SerializeField]
    private static float RubberRopePositionY => 23f;
    [SerializeField]
    private static float RubberRopeHeight => 5f;

    [Header("Pucks Settings")]
    public GameObject puckPrefab;
    
    
    
    public float PuckRadius => 2f;
    public Vector2 FieldSize => new Vector2(29.75f, 28f);
    
    private float CrossbarHeight => 1f;
    private float CrossbarWidth;
    private float CrossbarWidthEasy => 5.6f;
    private float CrossbarWidthMiddle => 5.0f;
    private float CrossbarWidthHard => 4.4f;

    static GameBoard()
    {
        var difficult = Difficult.Easy;

        switch (difficult)
        {
            case Difficult.Middle:
                CrossbarWidth = CrossbarWidthMiddle;
                break;
            case Difficult.Hard:
                CrossbarWidth = CrossbarWidthHard;
                break;
            case Difficult.Easy:
            default:
                CrossbarWidth = CrossbarWidthEasy;
                break;
        }

    }
    
    private void Awake()
    {
        //Instantiate(upperRubberRopePrefab, rubberRopesTransform);
        //Instantiate(lowerRubberRopePrefab, rubberRopesTransform);
    }
    
    public static void MoveToField(BoardSide side, ref Vector3 point)
    {
        var xSign = Mathf.Sign(point.x);
        var ySign = side == BoardSide.Upper ? 1 : -1;

        var weight = FieldSize.x / 2 - PuckRadius;
        var height = FieldSize.y - PuckRadius - RubberRopeThickness;
        
        weight = Mathf.Abs(point.y) > RubberRopePositionY ? weight - RubberRopeThickness : weight;

        if (side == BoardSide.Upper)
        {
            point.y = point.y > 0
                ? point.y > height ? height : point.y
                : 0;
        }
        else
        {
            point.y = point.y > 0
                ? 0
                : point.y > -height ? point.y : -height;
        }

        point.y = Mathf.Abs(point.y) < CrossbarHeight 
            ? Mathf.Abs(point.x) < CrossbarWidth / 2 ? point.y : (PuckRadius + CrossbarHeight) * ySign
            : point.y;
        
        weight = Mathf.Abs(point.y) < CrossbarHeight 
            ? Mathf.Abs(point.x) < CrossbarWidth / 2 - PuckRadius ? weight : CrossbarWidth / 2 - PuckRadius
            : weight;
        
        point.x = Mathf.Abs(point.x) > weight ? weight * xSign : point.x;
    }
    
    public static void LockY(BoardSide side, ref Vector3 point, ref float lastY)
    {
        lastY = Mathf.Abs(point.y) < Mathf.Abs(RubberRopePositionY - PuckRadius)
            ? Mathf.Abs(point.y) < Mathf.Abs(lastY) ? lastY : point.y
            : point.y;

        point.y = lastY;
    }
}
